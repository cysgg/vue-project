# @vue/compiler-core
