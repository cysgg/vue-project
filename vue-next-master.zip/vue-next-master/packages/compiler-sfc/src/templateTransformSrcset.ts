import { NodeTransform } from '@vue/compiler-core'

export const transformSrcset: NodeTransform = () => {
  // TODO
}
