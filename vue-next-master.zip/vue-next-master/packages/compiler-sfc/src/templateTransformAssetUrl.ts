import { NodeTransform } from '@vue/compiler-core'

export const transformAssetUrl: NodeTransform = () => {
  // TODO
}
